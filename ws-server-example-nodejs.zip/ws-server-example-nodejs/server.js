import WebSocket, { WebSocketServer } from 'ws';
import { randomUUID } from 'crypto';
const clients = new Map(); // has to be a Map instead of {} due to non-string keys
const wss = new WebSocketServer({ port: 8080 }); // initiate a new server that listens on port 8080

const eventTypes = {
    connected: 'connected',
    disconnected: 'disconnected',
    widgetCreated: 'widgetCreated',
    widgetUpdated: 'widgetUpdated',
    widgetDeleted: 'widgetDeleted',
}

const widgetTypes = {
    note: 'note',
    shape: 'shape',
    card: 'card',
}

const createMessage = (type, message, payload) => {
    return {
        type,
        message,
        payload,
    }
}

const randomNumber = (min, max) => {
    return Math.round(Math.random() * (max - min) + min, 2);
}

const randomCoord = () => randomNumber(-100, 100)

const connectedMessage = clientId => createMessage(eventTypes.connected,`Succesfully connected ${clientId}`, {clientId})
const widgetCreatedMessage = () => createMessage(eventTypes.widgetCreated, 'Created widget', {
    id: randomUUID(),
    xPos: randomCoord(),
    yPos: randomCoord(),
    content: "yolo",
    color: "red",
    widgetType: widgetTypes.note
})

// set up event handlers and do other things upon a client connecting to the server
wss.on('connection', (ws) => {
    // create an id to track the client
    const id = randomUUID();
    clients.set(ws, id);
    console.log(`new connection assigned id: ${id}`);

    // send a message to all connected clients upon receiving a message from one of the connected clients
    ws.on('message', (data) => {
        console.log(`received: ${data}`);
        serverBroadcast(`Client ${clients.get(ws)} ${data}`);
    });

    // stop tracking the client upon that client closing the connection
    ws.on('close', () => {
        console.log(`connection (id = ${clients.get(ws)}) closed`);
        clients.delete(ws);
    });

    // send the id back to the newly connected client
    ws.send(JSON.stringify(connectedMessage(id)));
});

// send a message to all the connected clients about how many of them there are every 15 seconds
setInterval(() => {
    console.log(`Number of connected clients: ${clients.size}`);
    serverBroadcast(JSON.stringify(widgetCreatedMessage()));
}, 5000);

// function for sending a message to every connected client
function serverBroadcast(message) {
    wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(message);
        }
    });
}

console.log('The server is running and waiting for connections');